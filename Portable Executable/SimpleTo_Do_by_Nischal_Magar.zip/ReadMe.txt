                                             SimpleTo_Do by Nischal Magar

A simple todo list made in C++ using the QT framework.

OTHER Frameworks used:

SQLITE for Database
JSON for saving interchangeable data (in this case the settings)



GitHub repo:

https://github.com/Nischall01/SimpleTo_Do-GUI-
